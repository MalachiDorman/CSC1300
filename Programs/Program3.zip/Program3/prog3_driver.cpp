/*******************************************************                          
* Purpose: should only contain the                     *
* main function definition                             *
*                                                      *
*******************************************************/

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include "prog3.h"

using namespace std;

int main(){

    srand(time(0)); // Random number generator

    // Welcome message
    cout << "WELCOME TO THE ONE PIECE BOARD GAME!" << endl;
    
    // Get player names

    getPlayersNames(string names[], int numPlayers)


    
}