/******************************************                        
* Purpose: should contain the function    *
* definitions of all functions other      *
* than the main function                  *
*                                         *
******************************************/

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <string>
#include "prog3.h"

using namespace std;

const int maxPlay = 20;
const int boardSpace = 25;


void getPlayersNames(string names[], int numPlayers) {
    do {
        cout << "How many pirates are aboard? (Max 20): ";
        cin >> numPlayers;

        if (numPlayers < 1 || numPlayers > maxPlay) {
            cout << "Invalid number! Please enter between 1 and 20\n";
        }
    } while (numPlayers < 1 || numPlayers > maxPlay);

    // Get player names
    for (int i = 0; i < numPlayers; i++) {
        cout << "What is your name, pirate" << i + 1 << "?: ";
        cin >> names[i];
    }
}
int rollDice(string playerName);


void playerFinishedBoard(string names[], int boardSpace[], double money[], int numPlayers);


void activateActionOnSpace(string names[], int boardSpace[], double money[], int numPlayers, int currentPlayer);


void printSmiley(){

    cout << "       _.-'''''-._      " << endl;
    cout << "    .'  _     _  '.    " << endl;
    cout << "   /   (_)   (_)   \\   " << endl;
    cout << "  |  ,           ,  |  " << endl;
    cout << "  |  \\`.       .`/  |  " << endl;
    cout << "   \\  '.`'\"\"'\"`.'  /   " << endl;
    cout << "    '.  `'---'`  .'    " << endl;
    cout << "      '-._____.-'      " << endl;
}
void printFrown(){
    cout << "         XXXXXXXXXXX         " << endl;
    cout << "      XXX           XXX      " << endl;
    cout << "    XX                 XX    " << endl;
    cout << "  XX                     XX  " << endl;
    cout << " X      XXX    X X X       X " << endl;
    cout << " X   XXX          XXXX     X " << endl;
    cout << "X                           X" << endl;
    cout << "X                           X" << endl;
    cout << "X                           X" << endl;
    cout << " X        XXXXXXX          X " << endl;
    cout << " X      XXX     XXX        X " << endl;
    cout << "  XX    X         X      XX  " << endl;
    cout << "    XX                 XX    " << endl;
    cout << "      XXX           XXX      " << endl;
    cout << "         XXXXXXXXXXX         " << endl;


}